# Mod Shazam untuk Minecraft 1.21.1 (NeoForge)

Versi 0.6.0. Isinya:
- Transformasi SHAZAM beranimasi, enam kekuatan S-H-A-Z-A-M, dan Energi Petir.
- Enam skill yang masing-masing punya gerakan dan efek sendiri.
- Terbang berbasis momentum ala Create: Lanterns: sonic boom, barrel roll, hero landing, dan kamera menikung.
- Kekuatan seperti di komik: darah 100, tahan banting, pukulan 20, dan Energi Petir 1000.
- Kostum yang otomatis terpakai saat berubah, lengkap dengan animasi pergantiannya, plus kostum armor 4 bagian yang bisa di-craft.
- Enam penjaga kuil beserta totemnya.

## Yang dibutuhkan

- **JDK 21**, misalnya Eclipse Temurin 21 atau Microsoft Build of OpenJDK 21.
- **Internet** untuk build pertama. Gradle, NeoForge, dan Minecraft diunduh otomatis, totalnya beberapa ratus MB.

## Bikin file .jar

**Windows:** buka folder ini, ketik `cmd` di address bar File Explorer, tekan Enter, lalu jalankan:

    gradlew build

**Mac/Linux:**

    chmod +x gradlew
    ./gradlew build

Hasilnya ada di `build/libs/shazammod-0.6.0.jar`. Taruh di folder `.minecraft/mods`, dengan NeoForge 21.1.228 atau yang lebih baru untuk Minecraft 1.21.1.

Mau ngetes tanpa install? Jalankan `gradlew runClient`.

## Kontrol

Semua tombol bisa diganti di pengaturan Controls, kategori Shazam.

| Tombol | Skill | Gerakan & efek |
|---|---|---|
| G (atau ketik `shazam`) | Transformasi | Kepalan diangkat ke langit, petir sihir menyambar, layar berkilat, ledakan asap, lalu berdiri gagah. Badan jadi 10% lebih besar. |
| Z | S - Mata Solomon | Dua jari ke pelipis, huruf-huruf sihir terserap ke kepala, dan gelombang cahaya menyebar. Semua musuh dalam 48 blok bersinar dan menerima +25% damage selama 10 detik. |
| X | H - Tepukan Hercules | Tangan dibentang lebar lalu ditepuk. Gelombang kejut berbentuk kerucut menghempas musuh di depan. |
| C | A - Hantaman Atlas | Di udara: menukik dengan kedua kepalan di atas kepala. Di tanah: kepalan diangkat lalu dihantamkan. Tanah retak melingkar dan musuh terlempar ke atas. |
| V | Z - Petir Zeus | Tangan menggapai langit lalu menunjuk sasaran, dan petir menyambar titik itu. |
| B | A - Kulit Achilles | Membungkuk mengumpulkan tenaga lalu meraung. Selama 6 detik badan diselubungi energi emas dan hampir kebal, sementara musuh di sekitar terdorong dan melemah. |
| N | M - Kilat Mercury | Menerjang secepat kilat dengan bayangan berjejak. Musuh di jalur terlempar ke samping. |
| H | Hood naik/turun | Hood dipakai di kepala atau diturunkan ke belakang leher. Statusnya tersimpan dan terlihat oleh pemain lain. |

## Terbang

| Kontrol | Gerakan |
|---|---|
| Spasi 2x | Lepas landas: jongkok sebentar, lalu melesat ke atas. Di udara, tekan lagi 2x untuk berhenti terbang. |
| W | Terbang ke arah pandangan (±28 blok/detik). |
| W + sprint (ditahan) | Makin lama makin ngebut sampai ±100 blok/detik. Saat menembus kecepatan tertentu muncul sonic boom: cincin uap, dentuman, dan musuh di sekitar terhempas. |
| S | Mengerem. Badan tegak dan tangan menahan ke depan. |
| Spasi / Shift | Naik / turun. |
| A / D | Geser ke samping (hanya di kecepatan rendah). |
| A 2x / D 2x | Barrel roll menghindar ke kiri/kanan. |

Pose terbang mengikuti arah gerak. Saat melayang, Shazam santai dengan satu kaki agak ke belakang. Saat meluncur, badan rebah dengan satu kepalan di depan. Saat super cepat, kedua kepalan di depan seperti peluru, badan tegak saat naik dan kepala di bawah saat menukik. Badan dan kamera ikut miring saat berbelok, dan pandangan melebar sesuai kecepatan.

Mendarat atau jatuh dengan kencang memicu hero landing: satu lutut turun, kepalan menghantam tanah, dan gelombang kejut melukai musuh di sekitar. Menabrak dinding dengan kencang juga menimbulkan gelombang kejut.

## Kekuatan saat jadi Shazam

| Bagian | Nilai |
|---|---|
| Darah | 100 (bar darah sendiri menggantikan baris hati), pulih 2 per detik |
| Ketahanan | damage yang diterima tinggal 40%, ditambah armor +10 dan toughness +6 |
| Kebal | jatuh, petir, api, lava, tenggelam (nggak perlu napas), beku, lapar, kaktus, racun, wither |
| Kelemahan | sihir (+50% damage) |
| Pukulan tangan kosong | 20 (critical 30), musuh terpental jauh |
| Lain-lain | badan 10% lebih besar, naik blok tanpa melompat, jangkauan +1, menghancurkan blok 4x lebih cepat |
| Energi Petir | 1000, berkurang 1 per detik saat jadi Shazam (±16 menit) dan terisi 5 per detik sebagai manusia; badai petir mempercepat |

## Kostum dan jubah

Kostum sudah terpasang di `src/main/resources/assets/shazammod/textures/entity/shazam_suit.png` dan otomatis dipakai saat berubah.

- **Saat berubah:** tenaga terkumpul (percikan berputar naik), kepalan menembus langit, lalu petir sihir emas yang tebal menyambar bersama tiga petir kecil di sekelilingnya. Gelombang kejut melebar di tanah, Shazam terangkat melayang dengan kedua lengan terbuka, dan kostum terbentuk bagian demi bagian (dada, lengan, kepala, kaki) dalam selubung cahaya emas. Setelah itu dia turun ke pose berdiri gagah.
- **Saat kembali jadi manusia:** kostum luruh dengan urutan terbalik, dan badan menyusut kembali.

Untuk mengganti kostum, timpa file itu dengan skin lain berformat 64x64 lengan lebar (`docs/panduan_kostum.png` menunjukkan area tiap bagian tubuh), lalu build ulang. Kalau `runClient` sedang jalan, cukup tekan F3+T.

### Jubah 3D dan hood

Jubah putih muncul setelah kostum terbentuk, dan juga saat memakai Kostum Shazam (armor dada). Jubahnya kain 3D berfisika:

- Bagian atas menempel di bahu. Sisanya jatuh oleh gravitasi dan nggak menembus badan, termasuk saat terbang rebah.
- Saat diam menggantung sampai dekat tanah, saat jalan dan lari terangkat ke belakang, dan saat terbang berkibar hampir mendatar.
- Bergoyang tertiup angin (makin cepat makin kencang), melambat di air, dan jatuh lagi saat berhenti.

Tekan **H** untuk menaikkan atau menurunkan hood. Saat dipakai, hood ikut gerak kepala. Saat diturunkan, hood terlipat menggembung di belakang leher.

Warna dan motif jubah serta hood ada di `.../textures/entity/shazam_cape_cloth.png`. Gambar itu dibentangkan ke seluruh jubah: sisi kiri-kanan gambar = tepi kiri-kanan jubah, atas = bahu, bawah = ujung jubah. Cat ulang sesukamu lalu build ulang (atau F3+T saat `runClient`). Ukuran dan kekuatan fisikanya bisa diatur di bagian atas `ShazamCape.java`.

## Kostum armor (bisa di-craft)

Empat bagian, pertahanannya setara netherite, dan diperbaiki pakai emas. Tampilannya diambil dari `shazam_suit.png`, jadi selalu cocok dengan kostum saat berubah.

| Bagian | Resep (G = emas batangan, R = wol merah) |
|---|---|
| Kepala Kostum Shazam | `KKK / BHB / _L_`: K = wol hitam, B = pewarna cokelat, H = helm berlian, L = penangkal petir |
| Kostum Shazam | `RLR / GCG / R_R`: L = penangkal petir, C = baju zirah berlian |
| Celana Kostum Shazam | `GYG / RLR / R_R`: Y = balok emas, L = celana berlian |
| Sepatu Kostum Shazam | `G_G / RDR / G_G`: D = sepatu berlian |

(`_` = kotak kosong.) Kostum ini nggak memberi kekuatan; kekuatan Shazam tetap datang dari mengucapkan SHAZAM.

## Perintah tes

Perintah ini butuh cheat aktif.

- `/shazam unlock` dan `/shazam lock`: membuka atau mencabut kekuatan Shazam.
- `/shazam energy <0-1000>`: mengatur Energi Petir.
- `/shazam summon <solomon|hercules|atlas|zeus|achilles|mercury>`: memunculkan penjaga.

## Kalau build gagal

- **`Plugin [id: 'net.neoforged.moddev', version: '2.0.+'] was not found`:** ganti `2.0.+` di `build.gradle` dengan versi ModDevGradle yang tertulis di MDK NeoForge 1.21.1 resmi.
- **Error soal versi Java:** pastikan `JAVA_HOME` mengarah ke JDK 21.
- **Crash saat game dibuka dengan pesan `Mixin`:** salin pesan error-nya dari `logs/latest.log` untuk diperbaiki.

## Soal gradle-wrapper.jar

`gradle/wrapper/gradle-wrapper.jar` adalah pengganti ringkas untuk wrapper resmi Gradle. Sumbernya ada di `gradle/wrapper/GradleWrapperMain.java`. Cara kerjanya: mengunduh Gradle 8.14.3 sekali ke `~/.gradle/wrapper/dists`, lalu menjalankannya.

Kalau mau memakai wrapper resmi, ada dua cara:
- Kalau Gradle sudah terpasang, jalankan `gradle wrapper --gradle-version 8.14.3` di folder ini.
- Salin folder `gradle/` dan file `gradlew*` dari MDK resmi.
