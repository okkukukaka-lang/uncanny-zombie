package org.gradle.wrapper;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Pengganti ringkas gradle-wrapper.jar resmi (sumber dari gradle-wrapper.jar di folder ini).
 * Membaca gradle-wrapper.properties, mengunduh distribusi Gradle sekali ke
 * ~/.gradle/wrapper/dists (lokasi yang sama dengan wrapper resmi), lalu menjalankannya.
 */
public final class GradleWrapperMain {
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        File wrapperJar = new File(GradleWrapperMain.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        File wrapperDir = wrapperJar.getParentFile();
        Properties props = new Properties();
        InputStream in = new FileInputStream(new File(wrapperDir, "gradle-wrapper.properties"));
        try {
            props.load(in);
        } finally {
            in.close();
        }

        String url = props.getProperty("distributionUrl");
        if (url == null || url.trim().isEmpty()) {
            throw fail("distributionUrl tidak ada di gradle-wrapper.properties");
        }
        url = url.trim();
        String zipName = url.substring(url.lastIndexOf('/') + 1);
        String distName = zipName.endsWith(".zip") ? zipName.substring(0, zipName.length() - 4) : zipName;

        File distDir = new File(new File(new File(gradleUserHome(), "wrapper" + File.separator + "dists"), distName), hash(url));
        File marker = new File(distDir, zipName + ".ok");
        if (!marker.isFile()) {
            install(url, props.getProperty("distributionSha256Sum"), distDir, zipName);
            if (!marker.createNewFile() && !marker.isFile()) {
                throw fail("Tidak bisa menulis " + marker);
            }
        }
        System.exit(run(findGradleHome(distDir), args));
    }

    private static File gradleUserHome() {
        String fromProperty = System.getProperty("gradle.user.home");
        if (fromProperty != null && !fromProperty.isEmpty()) {
            return new File(fromProperty);
        }
        String fromEnv = System.getenv("GRADLE_USER_HOME");
        if (fromEnv != null && !fromEnv.isEmpty()) {
            return new File(fromEnv);
        }
        return new File(System.getProperty("user.home"), ".gradle");
    }

    /** Sama seperti wrapper resmi: MD5 dari URL distribusi, basis 36. */
    private static String hash(String text) throws Exception {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        md5.update(text.getBytes("UTF-8"));
        return new BigInteger(1, md5.digest()).toString(36);
    }

    private static void install(String url, String sha256, File distDir, String zipName) throws Exception {
        if (!distDir.isDirectory() && !distDir.mkdirs()) {
            throw fail("Tidak bisa membuat folder " + distDir);
        }
        File part = new File(distDir, zipName + ".part");
        File zip = new File(distDir, zipName);
        System.out.println("Mengunduh " + url);
        try {
            download(url, part);
        } catch (IOException e) {
            part.delete();
            throw fail("Gagal mengunduh Gradle (" + e + "). Cek koneksi internet, lalu jalankan lagi.");
        }
        if (sha256 != null && !sha256.trim().isEmpty()) {
            String actual = sha256Of(part);
            if (!actual.equalsIgnoreCase(sha256.trim())) {
                part.delete();
                throw fail("Checksum distribusi Gradle tidak cocok (dapat " + actual + ")");
            }
        }
        if (zip.exists() && !zip.delete()) {
            throw fail("Tidak bisa menimpa " + zip);
        }
        if (!part.renameTo(zip)) {
            throw fail("Tidak bisa menyimpan " + zip);
        }
        System.out.println("Mengekstrak " + zipName);
        unzip(zip, distDir);
        zip.delete();
    }

    private static void download(String address, File target) throws IOException {
        URLConnection connection = new URL(address).openConnection();
        connection.setRequestProperty("User-Agent", "gradlew-shazammod");
        connection.setConnectTimeout(30000);
        connection.setReadTimeout(60000);
        if (connection instanceof HttpURLConnection) {
            HttpURLConnection http = (HttpURLConnection) connection;
            http.setInstanceFollowRedirects(true);
            int code = http.getResponseCode();
            if (code >= 400) {
                throw fail("Server membalas HTTP " + code + " untuk " + address);
            }
        }
        long total = connection.getContentLengthLong();
        InputStream in = new BufferedInputStream(connection.getInputStream());
        OutputStream out = new FileOutputStream(target);
        try {
            byte[] buffer = new byte[65536];
            long done = 0;
            int lastShown = -1;
            int read;
            while ((read = in.read(buffer)) > 0) {
                out.write(buffer, 0, read);
                done += read;
                if (total > 0) {
                    int percent = (int) (done * 100 / total);
                    if (percent / 10 != lastShown / 10) {
                        System.out.print(percent + "% ");
                        System.out.flush();
                        lastShown = percent;
                    }
                }
            }
            System.out.println();
        } finally {
            in.close();
            out.close();
        }
    }

    private static String sha256Of(File file) throws Exception {
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        InputStream in = new BufferedInputStream(new FileInputStream(file));
        try {
            byte[] buffer = new byte[65536];
            int read;
            while ((read = in.read(buffer)) > 0) {
                sha.update(buffer, 0, read);
            }
        } finally {
            in.close();
        }
        StringBuilder hex = new StringBuilder();
        for (byte b : sha.digest()) {
            hex.append(String.format("%02x", b));
        }
        return hex.toString();
    }

    private static void unzip(File zip, File dest) throws IOException {
        String destPath = dest.getCanonicalPath() + File.separator;
        ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)));
        try {
            byte[] buffer = new byte[65536];
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                File out = new File(dest, entry.getName());
                if (!out.getCanonicalPath().startsWith(destPath)) {
                    throw new IOException("Isi zip mencurigakan: " + entry.getName());
                }
                if (entry.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                out.getParentFile().mkdirs();
                OutputStream os = new FileOutputStream(out);
                try {
                    int read;
                    while ((read = zin.read(buffer)) > 0) {
                        os.write(buffer, 0, read);
                    }
                } finally {
                    os.close();
                }
            }
        } finally {
            zin.close();
        }
    }

    private static File findGradleHome(File distDir) {
        File[] children = distDir.listFiles();
        if (children != null) {
            for (File child : children) {
                if (child.isDirectory() && new File(child, "bin").isDirectory()) {
                    return child;
                }
            }
        }
        throw fail("Distribusi Gradle di " + distDir + " rusak. Hapus folder itu lalu jalankan lagi.");
    }

    private static int run(File gradleHome, String[] args) throws Exception {
        boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
        File bin = new File(gradleHome, "bin");
        List<String> command = new ArrayList<String>();
        if (windows) {
            command.add("cmd.exe");
            command.add("/c");
            command.add(new File(bin, "gradle.bat").getAbsolutePath());
        } else {
            File script = new File(bin, "gradle");
            script.setExecutable(true);
            command.add(script.getAbsolutePath());
        }
        command.addAll(Arrays.asList(args));
        ProcessBuilder builder = new ProcessBuilder(command).inheritIO();
        builder.environment().put("JAVA_HOME", System.getProperty("java.home"));
        return builder.start().waitFor();
    }

    private static RuntimeException fail(String message) {
        System.err.println("ERROR: " + message);
        System.exit(1);
        return new IllegalStateException(message);
    }
}
