package com.shazammod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: status Shazam seorang pemain (buat kostum, jubah, hood, dan pose terbang). */
public record ShazamStatePayload(int entityId, boolean transformed, boolean flying, boolean hood) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShazamStatePayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("state"));

    public static final StreamCodec<ByteBuf, ShazamStatePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShazamStatePayload::entityId,
            ByteBufCodecs.BOOL, ShazamStatePayload::transformed,
            ByteBufCodecs.BOOL, ShazamStatePayload::flying,
            ByteBufCodecs.BOOL, ShazamStatePayload::hood,
            ShazamStatePayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
