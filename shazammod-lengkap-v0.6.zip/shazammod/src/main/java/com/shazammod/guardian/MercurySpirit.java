package com.shazammod.guardian;

import com.shazammod.ShazamItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.allay.Allay;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

/**
 * Penjaga Mercury: roh cepat yang kabur sambil membawa totemnya.
 * Sesekali berhenti karena lelah. Totem di tangannya jatuh saat dia kalah.
 */
public class MercurySpirit extends Allay implements ShazamGuardian, Enemy {
    private static final double HOME_RADIUS = 24.0;
    private final GuardianCore core = new GuardianCore(this, BossEvent.BossBarColor.WHITE,
            null, "hint.shazammod.mercury");
    private BlockPos home;
    private int runTicks = 120;
    private int restTicks;

    public MercurySpirit(EntityType<? extends MercurySpirit> type, Level level) {
        super(type, level);
        this.xpReward = 50;
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ShazamItems.TOTEM_MERCURY.get()));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Allay.createAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.FLYING_SPEED, 0.2)
                .add(Attributes.MOVEMENT_SPEED, 0.2)
                .add(Attributes.SCALE, 1.6);
    }

    @Override
    public GuardianCore core() {
        return core;
    }

    @Override
    protected void customServerAiStep() {
        // Sengaja kosong: otak Allay bawaan (ikut pemain, ambil barang) dimatikan
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        return InteractionResult.PASS; // nggak bisa dikasih barang
    }

    @Override
    public boolean wantsToPickUp(ItemStack stack) {
        return false;
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide) {
            core.tick();
            if (home == null) {
                home = this.blockPosition();
            }
        }
        float healthBefore = this.getHealth();
        super.aiStep();
        if (!this.level().isClientSide && this.isAlive()) {
            if (this.getHealth() > healthBefore) {
                this.setHealth(healthBefore); // roh ini nggak bisa memulihkan diri
            }
            if (!core.isDormant()) {
                tickFlee();
            }
        }
    }

    private void tickFlee() {
        if (restTicks > 0) {
            restTicks--;
            this.getMoveControl().setWantedPosition(this.getX(), this.getY(), this.getZ(), 0.0);
            ((ServerLevel) this.level()).sendParticles(ParticleTypes.CLOUD,
                    this.getX(), this.getY() + 0.8, this.getZ(), 1, 0.2, 0.1, 0.2, 0.01);
            if (restTicks == 0) {
                runTicks = 100 + this.getRandom().nextInt(60);
            }
            return;
        }
        if (--runTicks <= 0) {
            restTicks = 50; // kelelahan 2,5 detik: kesempatan mengejar
            this.playSound(SoundEvents.ALLAY_HURT, 1f, 0.6f);
            return;
        }
        Player chaser = this.level().getNearestPlayer(this.getX(), this.getY(), this.getZ(), 32.0,
                EntitySelector.NO_CREATIVE_OR_SPECTATOR);
        if (chaser == null) {
            return;
        }
        Vec3 away = this.position().subtract(chaser.position());
        Vec3 dir = new Vec3(away.x, 0, away.z).normalize();
        Vec3 goal = this.position().add(dir.scale(6.0));
        Vec3 homeCenter = Vec3.atCenterOf(home);
        if (goal.distanceToSqr(homeCenter) > HOME_RADIUS * HOME_RADIUS) {
            // Jangan kabur terlalu jauh dari kuil: belok mengitari
            Vec3 toHome = homeCenter.subtract(this.position());
            Vec3 side = new Vec3(-dir.z, 0, dir.x);
            goal = this.position().add(new Vec3(toHome.x, 0, toHome.z).normalize().scale(4.0)).add(side.scale(4.0));
        }
        int groundY = this.level().getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(goal.x), Mth.floor(goal.z));
        this.getMoveControl().setWantedPosition(goal.x, groundY + 2.5, goal.z, 1.0);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && core.isDormant()) {
            core.wake();
        }
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        core.onDeath();
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || core.isDormant();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        core.startSeen(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        core.stopSeen(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        core.save(tag);
        if (home != null) {
            tag.putInt("HomeX", home.getX());
            tag.putInt("HomeY", home.getY());
            tag.putInt("HomeZ", home.getZ());
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        core.load(tag);
        if (tag.contains("HomeX")) {
            home = new BlockPos(tag.getInt("HomeX"), tag.getInt("HomeY"), tag.getInt("HomeZ"));
        }
    }
}
