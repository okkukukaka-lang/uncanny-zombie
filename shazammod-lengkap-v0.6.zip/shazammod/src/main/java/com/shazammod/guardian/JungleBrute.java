package com.shazammod.guardian;

import com.shazammod.ShazamItems;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/** Penjaga Hercules: menyeruduk. Kalau nabrak blok padat, dia pusing dan menerima damage dobel. */
public class JungleBrute extends Ravager implements ShazamGuardian {
    private final GuardianCore core = new GuardianCore(this, BossEvent.BossBarColor.GREEN,
            ShazamItems.TOTEM_HERCULES, "hint.shazammod.hercules");
    private int chargeCooldown = 60;
    private int windupTicks;
    private int chargeTicks;
    private int vulnerableTicks;
    private Vec3 chargeDir = Vec3.ZERO;

    public JungleBrute(EntityType<? extends JungleBrute> type, Level level) {
        super(type, level);
        this.xpReward = 50;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Ravager.createAttributes()
                .add(Attributes.MAX_HEALTH, 160.0)
                .add(Attributes.ATTACK_DAMAGE, 10.0)
                .add(Attributes.SCALE, 1.2);
    }

    @Override
    public GuardianCore core() {
        return core;
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide) {
            core.tick();
        }
        super.aiStep();
        if (!this.level().isClientSide && this.isAlive() && !core.isDormant()) {
            tickCharge();
        }
    }

    private void tickCharge() {
        ServerLevel level = (ServerLevel) this.level();
        if (vulnerableTicks > 0) {
            vulnerableTicks--;
        }
        if (windupTicks > 0) {
            // Ancang-ancang 1 detik: arah serudukan sudah terkunci, jadi bisa dihindari
            windupTicks--;
            level.sendParticles(ParticleTypes.CLOUD, this.getX(), this.getY() + 0.2, this.getZ(), 3, 0.8, 0.1, 0.8, 0.02);
            if (windupTicks == 0) {
                chargeTicks = 30;
                this.playSound(SoundEvents.RAVAGER_ROAR, 1.5f, 1.2f);
            }
            return;
        }
        if (chargeTicks > 0) {
            chargeTicks--;
            this.setDeltaMovement(chargeDir.x * 0.6, this.getDeltaMovement().y, chargeDir.z * 0.6);
            faceDirection(chargeDir);
            for (Player player : level.getEntitiesOfClass(Player.class, this.getBoundingBox().inflate(0.5),
                    p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
                player.hurt(this.damageSources().mobAttack(this), 14f);
                player.knockback(2.0, this.getX() - player.getX(), this.getZ() - player.getZ());
                player.hurtMarked = true;
                chargeTicks = 0;
            }
            if (chargeTicks > 0 && hitWall()) {
                stun();
            }
            return;
        }
        LivingEntity target = this.getTarget();
        if (target != null && --chargeCooldown <= 0) {
            double distance = this.distanceToSqr(target);
            if (distance > 6 * 6 && distance < 20 * 20 && this.hasLineOfSight(target)) {
                Vec3 to = target.position().subtract(this.position());
                chargeDir = new Vec3(to.x, 0, to.z).normalize();
                faceDirection(chargeDir);
                windupTicks = 20;
                chargeCooldown = 120;
                this.getNavigation().stop();
            } else {
                chargeCooldown = 20;
            }
        }
    }

    private void faceDirection(Vec3 dir) {
        float yaw = (float) (Mth.atan2(dir.z, dir.x) * (180.0 / Math.PI)) - 90.0f;
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.yHeadRot = yaw;
    }

    /** Nabrak sesuatu yang padat (bukan daun) di depannya? */
    private boolean hitWall() {
        if (!this.horizontalCollision) {
            return false;
        }
        Vec3 front = this.position().add(chargeDir.scale(this.getBbWidth() * 0.5 + 0.6));
        for (double dy : new double[] {0.5, 1.5}) {
            BlockPos pos = BlockPos.containing(front.x, this.getY() + dy, front.z);
            BlockState state = this.level().getBlockState(pos);
            if (!state.isAir() && !(state.getBlock() instanceof LeavesBlock)
                    && !state.getCollisionShape(this.level(), pos).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private void stun() {
        chargeTicks = 0;
        vulnerableTicks = 60;
        this.setDeltaMovement(Vec3.ZERO);
        // Pakai animasi pusing bawaan Ravager (sesudahnya dia mengaum)
        this.handleEntityEvent((byte) 39);
        this.level().broadcastEntityEvent(this, (byte) 39);
        this.playSound(SoundEvents.RAVAGER_STUNNED, 1.5f, 1f);
        ((ServerLevel) this.level()).sendParticles(ParticleTypes.CRIT,
                this.getX(), this.getY() + this.getBbHeight(), this.getZ(), 25, 0.6, 0.2, 0.6, 0.1);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && core.isDormant()) {
            core.wake();
        }
        if (vulnerableTicks > 0) {
            amount *= 2f; // lagi pusing: damage dobel
        }
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        core.onDeath();
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || core.isDormant() || windupTicks > 0 || chargeTicks > 0;
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        core.startSeen(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        core.stopSeen(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        core.save(tag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        core.load(tag);
    }
}
