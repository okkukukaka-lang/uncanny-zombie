package com.shazammod.guardian;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.shazammod.ShazamEntities;
import com.shazammod.ShazamItems;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Penjaga Solomon: memunculkan bayangan. Cuma yang asli (bukunya berkilau) yang bisa dilukai. */
public class ScholarZombie extends Zombie implements ShazamGuardian {
    private final GuardianCore core = new GuardianCore(this, BossEvent.BossBarColor.PURPLE,
            ShazamItems.TOTEM_SOLOMON, "hint.shazammod.solomon");
    private final List<UUID> illusions = new ArrayList<>();
    private int blindCooldown = 100;
    private int shuffleCooldown = 40;

    public ScholarZombie(EntityType<? extends ScholarZombie> type, Level level) {
        super(type, level);
        this.xpReward = 50;
        equip();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 80.0)
                .add(Attributes.ATTACK_DAMAGE, 6.0)
                .add(Attributes.MOVEMENT_SPEED, 0.26)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5);
    }

    private void equip() {
        this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.ENCHANTED_BOOK));
        this.setDropChance(EquipmentSlot.MAINHAND, 0f);
    }

    @Override
    public GuardianCore core() {
        return core;
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide) {
            core.tick();
            if (!core.isDormant() && this.isAlive()) {
                castSpells();
            }
        }
        super.aiStep();
    }

    private void castSpells() {
        LivingEntity target = this.getTarget();
        if (target == null) {
            return;
        }
        if (--blindCooldown <= 0 && this.hasLineOfSight(target) && this.distanceToSqr(target) < 16 * 16) {
            blindCooldown = 200;
            target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60), this);
            this.playSound(SoundEvents.ILLUSIONER_CAST_SPELL, 1f, 1f);
        }
        if (--shuffleCooldown <= 0) {
            shuffleCooldown = 300;
            shuffle();
        }
    }

    /** Munculkan 3 bayangan, lalu tukar tempat dengan salah satunya. */
    private void shuffle() {
        ServerLevel level = (ServerLevel) this.level();
        removeIllusions();
        List<ScholarIllusion> spawned = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            double angle = Math.PI * 2.0 / 3.0 * i + this.getRandom().nextDouble();
            double x = this.getX() + Math.cos(angle) * 4.0;
            double z = this.getZ() + Math.sin(angle) * 4.0;
            ScholarIllusion illusion = ShazamEntities.SCHOLAR_ILLUSION.get().create(level);
            if (illusion == null) {
                continue;
            }
            illusion.moveTo(x, this.getY(), z, this.getRandom().nextFloat() * 360f, 0f);
            illusion.setOwner(this);
            illusion.setTarget(this.getTarget());
            level.addFreshEntity(illusion);
            illusions.add(illusion.getUUID());
            spawned.add(illusion);
            level.sendParticles(ParticleTypes.POOF, x, this.getY() + 1.0, z, 12, 0.3, 0.5, 0.3, 0.02);
        }
        if (!spawned.isEmpty()) {
            ScholarIllusion swap = spawned.get(this.getRandom().nextInt(spawned.size()));
            Vec3 mine = this.position();
            this.teleportTo(swap.getX(), swap.getY(), swap.getZ());
            swap.teleportTo(mine.x, mine.y, mine.z);
        }
        level.sendParticles(ParticleTypes.POOF, this.getX(), this.getY() + 1.0, this.getZ(), 12, 0.3, 0.5, 0.3, 0.02);
        this.playSound(SoundEvents.ILLUSIONER_MIRROR_MOVE, 1f, 1f);
    }

    private void removeIllusions() {
        if (this.level() instanceof ServerLevel level) {
            for (UUID id : illusions) {
                Entity entity = level.getEntity(id);
                if (entity != null) {
                    entity.discard();
                }
            }
        }
        illusions.clear();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide && core.isDormant()) {
            core.wake();
        }
        return super.hurt(source, amount);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        removeIllusions();
        core.onDeath();
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || core.isDormant();
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    protected boolean convertsInWater() {
        return false;
    }

    @Override
    public void setBaby(boolean baby) {
        super.setBaby(false);
    }

    @Override
    protected void populateDefaultEquipmentSlots(RandomSource random, DifficultyInstance difficulty) {
        equip();
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        core.startSeen(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        core.stopSeen(player);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        core.save(tag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        core.load(tag);
    }
}
