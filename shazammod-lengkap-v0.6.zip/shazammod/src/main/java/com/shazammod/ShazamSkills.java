package com.shazammod;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Enam skill Shazam, satu untuk tiap huruf S-H-A-Z-A-M. Semuanya jalan di server;
 * gerakan dan efek visualnya diputar di client lewat ShazamAnim.
 */
public final class ShazamSkills {
    private ShazamSkills() {}

    public enum Skill {
        SOLOMON(40f, 600),    // S - Mata Solomon: membaca semua musuh di sekitar
        HERCULES(25f, 80),    // H - Tepukan Hercules: gelombang kejut berbentuk kerucut
        ATLAS(40f, 160),      // A - Hantaman Atlas: menghantam tanah dari udara
        ZEUS(20f, 30),         // Z - Petir Zeus: memanggil petir ke sasaran
        ACHILLES(80f, 900),   // A - Kulit Achilles: hampir kebal beberapa detik
        MERCURY(25f, 60);     // M - Kilat Mercury: menerjang secepat kilat

        public final float cost;
        public final int cooldownTicks;

        Skill(float cost, int cooldownTicks) {
            this.cost = cost;
            this.cooldownTicks = cooldownTicks;
        }
    }

    // ================= Angka-angka yang gampang diutak-atik =================
    private static final double SOLOMON_RADIUS = 48.0;

    private static final double CLAP_RANGE = 8.0;
    private static final double CLAP_CONE_COS = 0.5;   // lebar kerucut ±60°
    private static final float CLAP_DAMAGE = 18f;
    private static final double CLAP_KNOCKBACK = 2.2;

    private static final double SLAM_RADIUS = 6.0;
    private static final float SLAM_DAMAGE = 30f;
    private static final double SLAM_KNOCKBACK = 1.5;
    private static final int SLAM_TIMEOUT_TICKS = 60;

    private static final double ZEUS_RANGE = 32.0;
    private static final float ZEUS_DAMAGE = 18f;
    private static final double ZEUS_RADIUS = 2.5;

    private static final double ROAR_RADIUS = 6.0;
    public static final float ACHILLES_DAMAGE_MULTIPLIER = 0.15f;

    private static final double BLITZ_SPEED = 1.9;
    private static final float BLITZ_DAMAGE = 16f;
    // =========================================================================

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static final Map<UUID, Integer> SLAM_PENDING = new HashMap<>();
    private static final Map<UUID, Blitz> BLITZ = new HashMap<>();
    private static final Map<UUID, Long> ACHILLES_UNTIL = new HashMap<>();
    private static final Map<UUID, Long> EXPOSED_UNTIL = new HashMap<>();

    private static final class Blitz {
        int ticksLeft;
        final Vec3 dir;
        final Set<Integer> hit = new HashSet<>();

        Blitz(int ticksLeft, Vec3 dir) {
            this.ticksLeft = ticksLeft;
            this.dir = dir;
        }
    }

    // ----------------------------------------------------------- Pakai skill

    public static void use(ServerPlayer player, Skill skill) {
        if (!ShazamPowers.isTransformed(player)) {
            if (ShazamPowers.data(player).unlocked()) {
                player.displayClientMessage(Component.translatable("message.shazammod.not_transformed")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (cooldownTicks(player, skill) > 0) {
            return;
        }
        if (ShazamPowers.data(player).energy() < skill.cost) {
            player.displayClientMessage(Component.translatable("message.shazammod.skill_no_energy",
                    Math.round(skill.cost)).withStyle(ChatFormatting.RED), true);
            return;
        }

        boolean used = switch (skill) {
            case SOLOMON -> solomon(player);
            case HERCULES -> hercules(player);
            case ATLAS -> atlas(player);
            case ZEUS -> zeus(player);
            case ACHILLES -> achilles(player);
            case MERCURY -> mercury(player);
        };
        if (!used) {
            // Meleset: energi dan cooldown nggak terpakai
            player.displayClientMessage(Component.translatable("message.shazammod.no_target")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }

        ShazamData data = ShazamPowers.data(player);
        ShazamPowers.setData(player, data.withEnergy(data.energy() - skill.cost));
        READY_AT.computeIfAbsent(player.getUUID(), id -> new long[Skill.values().length])[skill.ordinal()] =
                player.level().getGameTime() + skill.cooldownTicks;
        ShazamNetwork.sync(player);
    }

    public static int cooldownTicks(ServerPlayer player, Skill skill) {
        long[] readyAt = READY_AT.get(player.getUUID());
        if (readyAt == null) {
            return 0;
        }
        long left = readyAt[skill.ordinal()] - player.level().getGameTime();
        return left > 0 ? (int) left : 0;
    }

    /** Efek dijalankan beberapa tick lagi, dan dibatalkan kalau pemain keburu balik jadi manusia. */
    private static void later(ServerPlayer player, int delay, Consumer<ServerPlayer> action) {
        ShazamPowers.schedule(player, delay, p -> {
            if (ShazamPowers.isTransformed(p)) {
                action.accept(p);
            }
        });
    }

    /** Dipanggil tiap tick selama pemain dalam wujud Shazam. */
    public static void tick(ServerPlayer player) {
        UUID id = player.getUUID();

        Integer slamLeft = SLAM_PENDING.get(id);
        if (slamLeft != null) {
            if (player.onGround() || player.isInWater() || player.isInLava()) {
                SLAM_PENDING.remove(id);
                slamImpact(player);
            } else if (slamLeft <= 1) {
                SLAM_PENDING.remove(id);
            } else {
                SLAM_PENDING.put(id, slamLeft - 1);
            }
        }

        Blitz blitz = BLITZ.get(id);
        if (blitz != null) {
            tickBlitz(player, blitz);
        }

        if (player.tickCount % 200 == 0) {
            long now = player.level().getGameTime();
            EXPOSED_UNTIL.values().removeIf(until -> until < now);
        }
    }

    /** Hentikan skill yang sedang berjalan (balik jadi manusia, respawn). Cooldown tetap jalan. */
    public static void cancelActive(ServerPlayer player) {
        UUID id = player.getUUID();
        SLAM_PENDING.remove(id);
        BLITZ.remove(id);
        ACHILLES_UNTIL.remove(id);
    }

    public static void forget(UUID id) {
        READY_AT.remove(id);
        SLAM_PENDING.remove(id);
        BLITZ.remove(id);
        ACHILLES_UNTIL.remove(id);
    }

    public static boolean isAchillesActive(ServerPlayer player) {
        Long until = ACHILLES_UNTIL.get(player.getUUID());
        return until != null && until > player.level().getGameTime();
    }

    public static boolean isExposed(LivingEntity entity) {
        Long until = EXPOSED_UNTIL.get(entity.getUUID());
        return until != null && until > entity.level().getGameTime();
    }

    // ---------------------------------------------------- S - Mata Solomon

    private static boolean solomon(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.SOLOMON_SIGHT);
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 1.2f, 0.8f);
        later(player, ShazamAnim.CAST_WINDUP, ShazamSkills::revealEnemies);
        return true;
    }

    private static void revealEnemies(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        long until = level.getGameTime() + ShazamAnim.SOLOMON_TICKS;
        for (LivingEntity enemy : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(SOLOMON_RADIUS),
                m -> m.isAlive() && m instanceof Enemy)) {
            enemy.addEffect(new MobEffectInstance(MobEffects.GLOWING, ShazamAnim.SOLOMON_TICKS, 0, false, false));
            EXPOSED_UNTIL.put(enemy.getUUID(), until);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 2f, 0.6f);
    }

    // ------------------------------------------------- H - Tepukan Hercules

    private static boolean hercules(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.HERCULES_CLAP);
        later(player, ShazamAnim.CAST_WINDUP, ShazamSkills::thunderclap);
        return true;
    }

    private static void thunderclap(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(CLAP_RANGE),
                m -> m.isAlive() && m instanceof Enemy)) {
            Vec3 toTarget = target.position().add(0, target.getBbHeight() * 0.5, 0).subtract(eye);
            double distance = toTarget.length();
            if (distance > CLAP_RANGE || distance < 0.01 || toTarget.normalize().dot(look) < CLAP_CONE_COS) {
                continue;
            }
            float falloff = (float) (1.0 - distance / CLAP_RANGE * 0.5);
            target.hurt(source, CLAP_DAMAGE * falloff);
            Vec3 push = new Vec3(toTarget.x, 0, toTarget.z).normalize().scale(CLAP_KNOCKBACK * falloff);
            target.push(push.x, 0.35, push.z);
        }
        for (int i = 1; i <= 3; i++) {
            Vec3 p = eye.add(look.scale(i * 2.0));
            level.sendParticles(ParticleTypes.SONIC_BOOM, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 1.2f, 1.6f);
    }

    // --------------------------------------------------- A - Hantaman Atlas

    private static boolean atlas(ServerPlayer player) {
        if (player.onGround() || player.isInWater()) {
            ShazamNetwork.playAnim(player, ShazamAnim.ATLAS_GROUND); // angkat kedua kepalan dulu
            later(player, ShazamAnim.CAST_WINDUP, ShazamSkills::slamImpact);
            return true;
        }
        // Di udara: menukik dulu, hantamannya terjadi waktu mendarat
        ShazamNetwork.playAnim(player, ShazamAnim.ATLAS_DIVE);
        player.getAbilities().flying = false;
        player.onUpdateAbilities();
        Vec3 look = player.getViewVector(1f);
        player.setDeltaMovement(look.x * 0.6, -2.5, look.z * 0.6);
        player.hurtMarked = true;
        SLAM_PENDING.put(player.getUUID(), SLAM_TIMEOUT_TICKS);
        return true;
    }

    private static void slamImpact(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.ATLAS_IMPACT);
        ServerLevel level = player.serverLevel();
        Vec3 center = player.position();
        DamageSource source = ShazamPowers.forceSource(player);
        double radiusSqr = SLAM_RADIUS * SLAM_RADIUS;
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(SLAM_RADIUS),
                m -> m.isAlive() && m instanceof Enemy && m.distanceToSqr(center) <= radiusSqr)) {
            target.hurt(source, SLAM_DAMAGE);
            Vec3 away = new Vec3(target.getX() - center.x, 0, target.getZ() - center.z);
            Vec3 push = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize().scale(SLAM_KNOCKBACK);
            target.push(push.x, 0.6, push.z); // tanah meledak ke atas
        }
        level.playSound(null, center.x, center.y, center.z, SoundEvents.MACE_SMASH_GROUND_HEAVY, SoundSource.PLAYERS, 1.5f, 0.7f);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 0.8f, 0.5f);
    }

    // ------------------------------------------------------- Z - Petir Zeus

    private static boolean zeus(ServerPlayer player) {
        LivingEntity entity = aimedEntity(player, ZEUS_RANGE);
        Vec3 target;
        if (entity != null) {
            target = entity.position();
        } else {
            BlockHitResult block = clipBlocks(player, ZEUS_RANGE);
            if (block.getType() == HitResult.Type.MISS) {
                return false;
            }
            target = block.getLocation();
        }
        ShazamNetwork.playAnim(player, ShazamAnim.ZEUS_CALL, target); // tangan ke langit, lalu menunjuk sasaran
        later(player, ShazamAnim.CAST_WINDUP, p -> ShazamPowers.strikeLightning(p, target, ZEUS_DAMAGE, ZEUS_RADIUS, 1.4f));
        return true;
    }

    // ------------------------------------------------- A - Kulit Achilles

    private static boolean achilles(ServerPlayer player) {
        ShazamNetwork.playAnim(player, ShazamAnim.ACHILLES_ROAR);
        later(player, ShazamAnim.ROAR_WINDUP, ShazamSkills::roar);
        return true;
    }

    private static void roar(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        ACHILLES_UNTIL.put(player.getUUID(), level.getGameTime() + ShazamAnim.ACHILLES_TICKS);
        Vec3 center = player.position();
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(ROAR_RADIUS),
                m -> m.isAlive() && m instanceof Enemy)) {
            Vec3 away = new Vec3(target.getX() - center.x, 0, target.getZ() - center.z);
            if (away.lengthSqr() > 1.0E-4) {
                away = away.normalize();
                target.push(away.x * 1.4, 0.3, away.z * 1.4);
            }
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1), player); // musuh kehilangan nyali
        }
        level.playSound(null, center.x, center.y, center.z, SoundEvents.RAVAGER_ROAR, SoundSource.PLAYERS, 1.2f, 1.3f);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 0.8f, 1.2f);
    }

    // ---------------------------------------------------- M - Kilat Mercury

    private static boolean mercury(ServerPlayer player) {
        Vec3 look = player.getViewVector(1f);
        Vec3 dir = player.getAbilities().flying ? look : new Vec3(look.x, 0, look.z);
        if (dir.lengthSqr() < 1.0E-4) {
            return false;
        }
        ShazamNetwork.playAnim(player, ShazamAnim.MERCURY_BLITZ);
        BLITZ.put(player.getUUID(), new Blitz(ShazamAnim.BLITZ_TICKS, dir.normalize()));
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.PHANTOM_SWOOP, SoundSource.PLAYERS, 1.2f, 1.6f);
        return true;
    }

    private static void tickBlitz(ServerPlayer player, Blitz blitz) {
        player.setDeltaMovement(blitz.dir.scale(BLITZ_SPEED));
        player.hurtMarked = true;
        ServerLevel level = player.serverLevel();
        DamageSource source = ShazamPowers.forceSource(player);
        AABB path = player.getBoundingBox().expandTowards(blitz.dir.scale(BLITZ_SPEED)).inflate(1.0);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, path,
                m -> m.isAlive() && m instanceof Enemy && !blitz.hit.contains(m.getId()))) {
            blitz.hit.add(target.getId());
            target.hurt(source, BLITZ_DAMAGE);
            Vec3 side = new Vec3(-blitz.dir.z, 0, blitz.dir.x);
            double sign = side.dot(target.position().subtract(player.position())) >= 0 ? 1.0 : -1.0;
            target.push(side.x * sign * 1.2, 0.4, side.z * sign * 1.2); // terlempar ke samping jalur
        }
        if (--blitz.ticksLeft <= 0) {
            BLITZ.remove(player.getUUID());
            player.setDeltaMovement(blitz.dir.scale(0.3));
            player.hurtMarked = true;
        }
    }

    // ------------------------------------------------------- Alat bantu bidik

    private static BlockHitResult clipBlocks(ServerPlayer player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getViewVector(1f).scale(range));
        return player.level().clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
    }

    /** Makhluk hidup yang sedang dilihat pemain (nggak tembus blok), atau null. */
    private static LivingEntity aimedEntity(ServerPlayer player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1f);
        BlockHitResult block = clipBlocks(player, range);
        Vec3 end = block.getType() == HitResult.Type.MISS ? eye.add(look.scale(range)) : block.getLocation();
        AABB box = player.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, eye, end, box,
                e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator() && e.isPickable(),
                eye.distanceToSqr(end));
        return hit != null && hit.getEntity() instanceof LivingEntity living ? living : null;
    }
}
