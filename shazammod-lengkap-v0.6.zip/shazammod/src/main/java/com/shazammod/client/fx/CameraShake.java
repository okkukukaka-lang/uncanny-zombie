package com.shazammod.client.fx;

import net.minecraft.util.Mth;
import net.neoforged.neoforge.client.event.ViewportEvent;

/** Guncangan kamera berbasis "trauma": tumbukan besar bikin guncangan keras yang reda pelan-pelan. */
public final class CameraShake {
    private CameraShake() {}

    private static float trauma;
    private static int time;

    public static void add(float amount) {
        trauma = Math.min(1f, trauma + amount);
    }

    public static void clear() {
        trauma = 0f;
    }

    public static void tick() {
        time++;
        trauma = Math.max(0f, trauma - 0.04f);
    }

    public static void apply(ViewportEvent.ComputeCameraAngles event) {
        if (trauma <= 0f) {
            return;
        }
        float shake = trauma * trauma;
        float t = time + (float) event.getPartialTick();
        event.setYaw(event.getYaw() + shake * 3.5f * wave(t, 0f));
        event.setPitch(event.getPitch() + shake * 3.5f * wave(t, 1.7f));
        event.setRoll(event.getRoll() + shake * 2.5f * wave(t, 3.1f));
    }

    private static float wave(float t, float seed) {
        return Mth.sin(t * 1.9f + seed) * 0.6f + Mth.sin(t * 3.7f + seed * 2.3f) * 0.4f;
    }
}
