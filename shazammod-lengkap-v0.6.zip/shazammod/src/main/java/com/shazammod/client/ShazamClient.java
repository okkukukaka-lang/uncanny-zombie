package com.shazammod.client;

import org.lwjgl.glfw.GLFW;

import com.shazammod.ShazamActionPayload;
import com.shazammod.ShazamAnim;
import com.shazammod.ShazamAnimPayload;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamEntities;
import com.shazammod.ShazamMod;
import com.shazammod.ShazamNetwork;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.flight.ShazamFlight;
import com.shazammod.client.fx.CameraShake;
import com.shazammod.client.fx.FovKick;
import com.shazammod.client.fx.ScreenFlash;
import com.shazammod.client.fx.ShazamFx;
import com.shazammod.client.render.AchillesAuraLayer;
import com.shazammod.client.render.MagicBoltRenderer;
import com.shazammod.client.render.ShazamCape;
import com.shazammod.client.render.ShazamSuit;
import com.shazammod.client.render.SuitRevealLayer;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.AllayRenderer;
import net.minecraft.client.renderer.entity.BreezeRenderer;
import net.minecraft.client.renderer.entity.IronGolemRenderer;
import net.minecraft.client.renderer.entity.RavagerRenderer;
import net.minecraft.client.renderer.entity.WitherSkeletonRenderer;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ComputeFovModifierEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Khusus client: keybind, HUD, renderer, animasi, dan efek. */
public final class ShazamClient {
    private ShazamClient() {}

    private static final String CATEGORY = "key.categories.shazammod";

    public static final KeyMapping TRANSFORM = new KeyMapping("key.shazammod.transform", GLFW.GLFW_KEY_G, CATEGORY);
    public static final KeyMapping HOOD = new KeyMapping("key.shazammod.hood", GLFW.GLFW_KEY_H, CATEGORY);
    /** Urutan S-H-A-Z-A-M, sama dengan ShazamSkills.Skill. */
    public static final KeyMapping[] SKILL_KEYS = {
            new KeyMapping("key.shazammod.solomon", GLFW.GLFW_KEY_Z, CATEGORY),
            new KeyMapping("key.shazammod.hercules", GLFW.GLFW_KEY_X, CATEGORY),
            new KeyMapping("key.shazammod.atlas", GLFW.GLFW_KEY_C, CATEGORY),
            new KeyMapping("key.shazammod.zeus", GLFW.GLFW_KEY_V, CATEGORY),
            new KeyMapping("key.shazammod.achilles", GLFW.GLFW_KEY_B, CATEGORY),
            new KeyMapping("key.shazammod.mercury", GLFW.GLFW_KEY_N, CATEGORY)
    };

    @EventBusSubscriber(modid = ShazamMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModEvents {
        private ModEvents() {}

        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(TRANSFORM);
            event.register(HOOD);
            for (KeyMapping key : SKILL_KEYS) {
                event.register(key);
            }
        }

        /** Sementara penjaga memakai tubuh mob vanilla; model khusus bisa menyusul. */
        @SubscribeEvent
        public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ShazamEntities.SCHOLAR_ZOMBIE.get(), ZombieRenderer::new);
            event.registerEntityRenderer(ShazamEntities.SCHOLAR_ILLUSION.get(), ZombieRenderer::new);
            event.registerEntityRenderer(ShazamEntities.JUNGLE_BRUTE.get(), RavagerRenderer::new);
            event.registerEntityRenderer(ShazamEntities.EARTH_GOLEM.get(), IronGolemRenderer::new);
            event.registerEntityRenderer(ShazamEntities.STORM_STALKER.get(), BreezeRenderer::new);
            event.registerEntityRenderer(ShazamEntities.UNDEAD_GLADIATOR.get(), WitherSkeletonRenderer::new);
            event.registerEntityRenderer(ShazamEntities.MERCURY_SPIRIT.get(), AllayRenderer::new);
            event.registerEntityRenderer(ShazamEntities.MAGIC_BOLT.get(), MagicBoltRenderer::new);
        }

        /** Animasi ganti kostum dan aura Achilles dipasang di model pemain (jubah 3D dirender terpisah). */
        @SubscribeEvent
        public static void addLayers(EntityRenderersEvent.AddLayers event) {
            for (PlayerSkin.Model skin : event.getSkins()) {
                if (event.getSkin(skin) instanceof PlayerRenderer renderer) {
                    renderer.addLayer(new SuitRevealLayer(renderer));
                    renderer.addLayer(new AchillesAuraLayer(renderer));
                }
            }
        }

        @SubscribeEvent
        public static void registerHud(RegisterGuiLayersEvent event) {
            event.registerAbove(VanillaGuiLayers.HOTBAR, ShazamMod.id("energy_hud"), ShazamHud::render);
            event.registerAboveAll(ShazamMod.id("lightning_flash"), ScreenFlash::render);
        }

        @SubscribeEvent
        public static void registerReload(RegisterClientReloadListenersEvent event) {
            event.registerReloadListener((ResourceManagerReloadListener) manager -> ShazamSuit.reset());
        }
    }

    @EventBusSubscriber(modid = ShazamMod.MODID, value = Dist.CLIENT)
    public static final class GameEvents {
        private GameEvents() {}

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) {
                return;
            }
            while (TRANSFORM.consumeClick()) {
                PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_TRANSFORM));
            }
            while (HOOD.consumeClick()) {
                PacketDistributor.sendToServer(new ShazamActionPayload(ShazamNetwork.ACTION_HOOD));
            }
            for (int i = 0; i < SKILL_KEYS.length; i++) {
                while (SKILL_KEYS[i].consumeClick()) {
                    PacketDistributor.sendToServer(new ShazamActionPayload(i + 1));
                }
            }
            if (mc.isPaused()) {
                return;
            }
            ShazamAnimPayload payload;
            while ((payload = ShazamClientState.pollAnim()) != null) {
                ShazamAnim anim = ShazamAnim.byId(payload.anim());
                if (anim != null && mc.level.getEntity(payload.entityId()) instanceof AbstractClientPlayer player) {
                    ShazamPoses.start(player, anim);
                    ShazamFx.onAnim(player, anim, new Vec3(payload.x(), payload.y(), payload.z()));
                    if (player == mc.player && anim == ShazamAnim.MERCURY_BLITZ) {
                        ShazamFlight.dash(mc.player); // terjangan tetap jalan walau sedang terbang
                    }
                }
            }
            ShazamPoses.tick(mc.level);
            ShazamCape.tick(mc.level);
            ShazamFx.tick(mc.level);
            CameraShake.tick();
            ScreenFlash.tick();
            FovKick.tick();
        }

        @SubscribeEvent
        public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
            // Bersihkan semua supaya nggak kebawa ke world/server lain
            ShazamFlight.reset(Minecraft.getInstance().player);
            ShazamClientState.reset();
            ShazamPoses.clear();
            ShazamCape.clear();
            ShazamFx.clear();
            CameraShake.clear();
            ScreenFlash.clear();
            FovKick.clear();
        }

        /** Kendali terbang: kecepatan diatur sebelum pemain bergerak, lalu cek lepas landas/mendarat. */
        @SubscribeEvent
        public static void onPlayerTickPre(PlayerTickEvent.Pre event) {
            if (event.getEntity() instanceof LocalPlayer player) {
                ShazamFlight.preTick(player);
            }
        }

        @SubscribeEvent
        public static void onPlayerTickPost(PlayerTickEvent.Post event) {
            if (event.getEntity() instanceof LocalPlayer player) {
                ShazamFlight.postTick(player);
            }
        }

        /** Saat jadi Shazam, baris hati diganti bar darah di HUD. */
        @SubscribeEvent
        public static void onGuiLayer(RenderGuiLayerEvent.Pre event) {
            if (ShazamClientState.transformed && event.getName().equals(VanillaGuiLayers.PLAYER_HEALTH)) {
                event.setCanceled(true);
            }
        }

        @SubscribeEvent
        public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
            CameraShake.apply(event);
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                event.setRoll(event.getRoll() + ShazamPoses.cameraRoll(mc.player, (float) event.getPartialTick()));
            }
        }

        @SubscribeEvent
        public static void onFov(ComputeFovModifierEvent event) {
            FovKick.apply(event);
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                float speed = ShazamPoses.flightSpeedFactor(mc.player, mc.getTimer().getGameTimeDeltaPartialTick(false));
                event.setNewFovModifier(event.getNewFovModifier() * (1f + 0.35f * speed)); // pandangan melebar saat ngebut
            }
        }

        @SubscribeEvent
        public static void onRenderPlayer(RenderPlayerEvent.Post event) {
            if (event.getEntity() instanceof AbstractClientPlayer player) {
                ShazamPoses.renderGhosts(player, event.getRenderer(), event.getPoseStack(),
                        event.getMultiBufferSource(), event.getPartialTick());
                ShazamCape.render(player, event.getRenderer(), event.getPoseStack(),
                        event.getMultiBufferSource(), event.getPartialTick(), event.getPackedLight());
            }
        }
    }
}
