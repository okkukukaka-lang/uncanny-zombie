package com.shazammod.client.render;

import com.shazammod.ShazamClientState;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.resources.ResourceLocation;

/**
 * Tekstur kostum Shazam (jubah 3D ada di ShazamCape).
 * - assets/shazammod/textures/entity/shazam_suit.png  (format skin 64x64, lengan lebar)
 * Kalau file-nya nggak ada, pemain tetap memakai skin biasanya.
 */
public final class ShazamSuit {
    private ShazamSuit() {}

    public static final ResourceLocation SUIT = ShazamMod.id("textures/entity/shazam_suit.png");

    private static Boolean suitPresent;

    public static boolean hasSuitTexture() {
        if (suitPresent == null) {
            suitPresent = exists(SUIT);
        }
        return suitPresent;
    }

    /** Tekstur badan untuk pemain ini, atau null = pakai skin biasa (termasuk selama kostum masih terbentuk). */
    public static ResourceLocation suitFor(AbstractClientPlayer player) {
        if (player == null || !ShazamClientState.isTransformed(player.getId()) || !hasSuitTexture()) {
            return null;
        }
        return ShazamPoses.isSuitRevealing(player) ? null : SUIT;
    }

    /** Model lengan lebar dipakai selama jadi Shazam dan selama kostum berganti. */
    public static boolean forceWide(AbstractClientPlayer player) {
        return hasSuitTexture()
                && (ShazamClientState.isTransformed(player.getId()) || ShazamPoses.isSuitChanging(player));
    }

    private static boolean exists(ResourceLocation location) {
        return Minecraft.getInstance().getResourceManager().getResource(location).isPresent();
    }

    /** Dipanggil saat resource pack dimuat ulang (F3+T). */
    public static void reset() {
        suitPresent = null;
    }
}
