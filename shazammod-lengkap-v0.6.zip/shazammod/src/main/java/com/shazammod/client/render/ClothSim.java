package com.shazammod.client.render;

/**
 * Simulasi kain sederhana (Verlet) untuk jubah: titik-titik dalam grid yang disambung "tali kaku".
 * Baris paling atas dipaku ke bahu; sisanya jatuh oleh gravitasi, tertinggal saat badan bergerak,
 * dan berkibar kena angin. Sengaja murni Java (tanpa class Minecraft) supaya gampang diuji.
 */
public final class ClothSim {
    /** Dipanggil tiap iterasi untuk menjauhkan kain dari badan dan lantai. */
    public interface Collider {
        void collide(ClothSim sim, int index);
    }

    public final int cols;
    public final int rows;
    public final int count;
    public final double[] x, y, z;      // posisi sekarang
    public final double[] px, py, pz;   // posisi tick lalu (kecepatan Verlet)
    public final double[] rx, ry, rz;   // posisi akhir tick lalu (buat interpolasi saat dirender)

    private final int[] linkA;
    private final int[] linkB;
    private final double[] rest;
    private final double[] stiffness;
    private final boolean[] vertical;
    private int links;
    private boolean ready;
    private double cx, cy, cz;

    public ClothSim(int cols, int rows, double[] restX, double[] restY, double[] restZ) {
        this.cols = cols;
        this.rows = rows;
        this.count = cols * rows;
        x = new double[count]; y = new double[count]; z = new double[count];
        px = new double[count]; py = new double[count]; pz = new double[count];
        rx = new double[count]; ry = new double[count]; rz = new double[count];
        int max = count * 8;
        linkA = new int[max];
        linkB = new int[max];
        rest = new double[max];
        stiffness = new double[max];
        vertical = new boolean[max];
        // Urutan baris atas -> bawah supaya tarikan dari bahu merambat dalam satu putaran
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int i = r * cols + c;
                if (c + 1 < cols) link(i, i + 1, 1.0, false, restX, restY, restZ);              // mendatar
                if (r + 1 < rows) link(i, i + cols, 1.0, true, restX, restY, restZ);            // tegak
                if (r + 1 < rows && c + 1 < cols) {                                              // silang
                    link(i, i + cols + 1, 0.5, false, restX, restY, restZ);
                    link(i + 1, i + cols, 0.5, false, restX, restY, restZ);
                }
                if (r + 2 < rows) link(i, i + 2 * cols, 0.3, false, restX, restY, restZ);       // kaku menekuk (tegak)
                if (c + 2 < cols) link(i, i + 2, 0.2, false, restX, restY, restZ);             // kaku menekuk (mendatar)
            }
        }
    }

    private void link(int a, int b, double k, boolean isVertical, double[] restX, double[] restY, double[] restZ) {
        double dx = restX[b] - restX[a];
        double dy = restY[b] - restY[a];
        double dz = restZ[b] - restZ[a];
        linkA[links] = a;
        linkB[links] = b;
        rest[links] = Math.sqrt(dx * dx + dy * dy + dz * dz);
        stiffness[links] = k;
        vertical[links] = isVertical;
        links++;
    }

    public boolean isReady() {
        return ready;
    }

    /** Jarak pusat bahu sekarang ke pusat bahu tick lalu (buat mendeteksi teleport). */
    public double distanceToCenter(double x0, double y0, double z0) {
        double dx = x0 - cx, dy = y0 - cy, dz = z0 - cz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Susun ulang kain ke bentuk diam (posisi dunia). */
    public void reset(double[] wx, double[] wy, double[] wz) {
        System.arraycopy(wx, 0, x, 0, count); System.arraycopy(wx, 0, px, 0, count); System.arraycopy(wx, 0, rx, 0, count);
        System.arraycopy(wy, 0, y, 0, count); System.arraycopy(wy, 0, py, 0, count); System.arraycopy(wy, 0, ry, 0, count);
        System.arraycopy(wz, 0, z, 0, count); System.arraycopy(wz, 0, pz, 0, count); System.arraycopy(wz, 0, rz, 0, count);
        cx = 0; cy = 0; cz = 0;
        for (int c = 0; c < cols; c++) {
            cx += wx[c]; cy += wy[c]; cz += wz[c];
        }
        cx /= cols; cy /= cols; cz /= cols;
        ready = true;
    }

    /**
     * Satu tick simulasi.
     * @param carry  seberapa banyak gerak badan ikut dibawa kain (sisanya tertinggal: jubah berkibar ke belakang)
     * @param windX  dorongan angin per tick (berlawanan arah gerak)
     * @param waveX  arah dan besar kibaran (bergoyang kiri-kanan, makin ke bawah makin besar)
     * @param scale  ukuran badan (jubah ikut membesar)
     */
    public void step(double[] anchorX, double[] anchorY, double[] anchorZ, double gravity, double damping, double carry,
                     double windX, double windY, double windZ, double waveX, double waveY, double waveZ,
                     double time, int iterations, double scale, Collider collider) {
        double ncx = 0, ncy = 0, ncz = 0;
        for (int c = 0; c < cols; c++) {
            ncx += anchorX[c]; ncy += anchorY[c]; ncz += anchorZ[c];
        }
        ncx /= cols; ncy /= cols; ncz /= cols;
        double sx = (ncx - cx) * carry;
        double sy = (ncy - cy) * carry;
        double sz = (ncz - cz) * carry;

        System.arraycopy(x, 0, rx, 0, count);
        System.arraycopy(y, 0, ry, 0, count);
        System.arraycopy(z, 0, rz, 0, count);

        for (int i = cols; i < count; i++) {
            int row = i / cols;
            int col = i % cols;
            double depth = row / (double) (rows - 1);
            double vx = (x[i] - px[i]) * damping;
            double vy = (y[i] - py[i]) * damping;
            double vz = (z[i] - pz[i]) * damping;
            double wave = depth * Math.sin(time * 1.3 + row * 0.8 + col * 0.5);
            px[i] = x[i] + sx;
            py[i] = y[i] + sy;
            pz[i] = z[i] + sz;
            x[i] += sx + vx + (windX + waveX * wave) * depth;
            y[i] += sy + vy - gravity + (windY + waveY * wave) * depth;
            z[i] += sz + vz + (windZ + waveZ * wave) * depth;
        }
        for (int c = 0; c < cols; c++) {
            x[c] = anchorX[c]; y[c] = anchorY[c]; z[c] = anchorZ[c];
            px[c] = anchorX[c]; py[c] = anchorY[c]; pz[c] = anchorZ[c];
        }

        for (int it = 0; it < iterations; it++) {
            for (int k = 0; k < links; k++) {
                satisfy(k, scale);
            }
            if (collider != null) {
                for (int i = cols; i < count; i++) {
                    collider.collide(this, i);
                }
            }
        }
        // Kain nggak boleh molor: tali tegak dibatasi maksimal 8% lebih panjang
        for (int k = 0; k < links; k++) {
            if (!vertical[k]) {
                continue;
            }
            int a = linkA[k], b = linkB[k];
            double dx = x[b] - x[a], dy = y[b] - y[a], dz = z[b] - z[a];
            double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
            double max = rest[k] * scale * 1.08;
            if (d > max) {
                double f = max / d;
                x[b] = x[a] + dx * f;
                y[b] = y[a] + dy * f;
                z[b] = z[a] + dz * f;
            }
        }
        cx = ncx; cy = ncy; cz = ncz;
    }

    private void satisfy(int k, double scale) {
        int a = linkA[k], b = linkB[k];
        boolean pinA = a < cols, pinB = b < cols;
        if (pinA && pinB) {
            return;
        }
        double dx = x[b] - x[a], dy = y[b] - y[a], dz = z[b] - z[a];
        double d = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (d < 1.0E-7) {
            return;
        }
        double diff = (d - rest[k] * scale) / d * stiffness[k];
        if (pinA) {
            x[b] -= dx * diff; y[b] -= dy * diff; z[b] -= dz * diff;
        } else if (pinB) {
            x[a] += dx * diff; y[a] += dy * diff; z[a] += dz * diff;
        } else {
            double h = diff * 0.5;
            x[a] += dx * h; y[a] += dy * h; z[a] += dz * h;
            x[b] -= dx * h; y[b] -= dy * h; z[b] -= dz * h;
        }
    }
}
