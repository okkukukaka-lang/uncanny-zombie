package com.shazammod.client.render;

import java.util.HashMap;
import java.util.Map;

import org.joml.Matrix4f;
import org.joml.Vector3f;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shazammod.ShazamClientState;
import com.shazammod.ShazamItems;
import com.shazammod.ShazamMod;
import com.shazammod.client.anim.ShazamPoses;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;

/**
 * Jubah 3D berfisika dan hood, dipakai saat jadi Shazam atau saat memakai Kostum Shazam.
 * Tekstur kain: assets/shazammod/textures/entity/shazam_cape_cloth.png (lebar = lebar jubah, tinggi = panjang jubah).
 */
public final class ShazamCape {
    private ShazamCape() {}

    public static final ResourceLocation TEXTURE = ShazamMod.id("textures/entity/shazam_cape_cloth.png");

    // ======= Ukuran jubah (blok, sebelum dikali ukuran badan) =======
    private static final int COLS = 7;
    private static final int ROWS = 12;
    private static final float TOP_WIDTH = 0.62f;
    private static final float BOTTOM_WIDTH = 0.92f;
    private static final float LENGTH = 1.20f;
    private static final float SHOULDER_Y = 1.40f;
    private static final float BACK_Z = 0.17f;
    private static final float NECK_Y = 1.407f;
    // ======= Fisika =======
    private static final double GRAVITY = 0.045;
    private static final double DAMPING = 0.96;
    private static final double CARRY = 0.82;     // sisa 18% gerak badan bikin jubah tertinggal dan berkibar
    private static final double WIND = 0.08;
    private static final double MAX_WIND = 0.12;
    private static final int ITERATIONS = 6;

    private static final double[] REST_X = new double[COLS * ROWS];
    private static final double[] REST_Y = new double[COLS * ROWS];
    private static final double[] REST_Z = new double[COLS * ROWS];

    static {
        for (int r = 0; r < ROWS; r++) {
            for (int c = 0; c < COLS; c++) {
                double v = r / (double) (ROWS - 1);
                double width = TOP_WIDTH + (BOTTOM_WIDTH - TOP_WIDTH) * v;
                int i = r * COLS + c;
                REST_X[i] = (c / (double) (COLS - 1) - 0.5) * width;
                REST_Y[i] = SHOULDER_Y - v * LENGTH;
                REST_Z[i] = BACK_Z + v * 0.05;
            }
        }
    }

    private static final class Cape {
        final ClothSim sim = new ClothSim(COLS, ROWS, REST_X, REST_Y, REST_Z);
        float bodyYaw;
        float bodyYawO;
        boolean started;
    }

    private static final Map<Integer, Cape> CAPES = new HashMap<>();

    public static void clear() {
        CAPES.clear();
    }

    /** Pakai jubah kalau sedang jadi Shazam (kostum sudah terbentuk) atau memakai Kostum Shazam. */
    public static boolean hasCape(AbstractClientPlayer player) {
        ItemStack chest = player.getItemBySlot(EquipmentSlot.CHEST);
        if (player.isInvisible() || chest.is(Items.ELYTRA)) {
            return false;
        }
        boolean shazam = ShazamClientState.isTransformed(player.getId()) && !ShazamPoses.isSuitRevealing(player);
        return shazam || chest.is(ShazamItems.SHAZAM_SUIT.get());
    }

    private static double crouchOffset(AbstractClientPlayer player) {
        return player.isCrouching() ? -0.125 * player.getScale() : 0.0;
    }

    // ------------------------------------------------------------------ simulasi (tick client)

    public static void tick(ClientLevel level) {
        CAPES.keySet().removeIf(id -> !(level.getEntity(id) instanceof AbstractClientPlayer p) || !hasCape(p));
        for (AbstractClientPlayer player : level.players()) {
            if (hasCape(player)) {
                simulate(player, CAPES.computeIfAbsent(player.getId(), id -> new Cape()));
            }
        }
    }

    private static void simulate(AbstractClientPlayer player, Cape cape) {
        cape.bodyYawO = cape.started ? cape.bodyYaw : player.yBodyRot;
        cape.bodyYaw = player.yBodyRot;
        cape.started = true;

        Matrix4f m = ShazamPoses.bodyMatrix(player, 1f, player.yBodyRot);
        double ox = player.getX();
        double oy = player.getY() + crouchOffset(player);
        double oz = player.getZ();
        Vector3f tmp = new Vector3f();

        double[] ax = new double[COLS];
        double[] ay = new double[COLS];
        double[] az = new double[COLS];
        double cx = 0, cy = 0, cz = 0;
        for (int c = 0; c < COLS; c++) {
            tmp.set((float) REST_X[c], (float) REST_Y[c], (float) REST_Z[c]);
            m.transformPosition(tmp);
            ax[c] = ox + tmp.x;
            ay[c] = oy + tmp.y;
            az[c] = oz + tmp.z;
            cx += ax[c]; cy += ay[c]; cz += az[c];
        }
        cx /= COLS; cy /= COLS; cz /= COLS;

        ClothSim sim = cape.sim;
        if (!sim.isReady() || sim.distanceToCenter(cx, cy, cz) > 8.0) {
            // Baru muncul atau teleport: susun jubah menggantung di punggung
            double[] wx = new double[sim.count];
            double[] wy = new double[sim.count];
            double[] wz = new double[sim.count];
            for (int i = 0; i < sim.count; i++) {
                tmp.set((float) REST_X[i], (float) REST_Y[i], (float) REST_Z[i]);
                m.transformPosition(tmp);
                wx[i] = ox + tmp.x;
                wy[i] = oy + tmp.y;
                wz[i] = oz + tmp.z;
            }
            sim.reset(wx, wy, wz);
            return;
        }

        boolean water = player.isInWater();
        double gravity = water ? 0.01 : GRAVITY;
        double damping = water ? 0.85 : DAMPING;
        Vec3 motion = new Vec3(player.getX() - player.xo, player.getY() - player.yo, player.getZ() - player.zo);
        double speed = motion.length();
        Vec3 wind = motion.scale(-WIND);
        if (wind.length() > MAX_WIND) {
            wind = wind.normalize().scale(MAX_WIND);
        }
        double flutter = speed < 0.05 ? 0.004 : Math.min(0.06, 0.012 + speed * 0.025);
        Vector3f side = m.transformDirection(new Vector3f(1f, 0f, 0f)).normalize();

        Matrix4f inverse = new Matrix4f(m).invert();
        double floor = player.onGround() ? player.getY() + 0.03 : Double.NEGATIVE_INFINITY;
        ClothSim.Collider collider = (s, i) -> {
            // Jangan menembus badan: dorong ke belakang punggung (dihitung di ruang badan, jadi ikut saat terbang rebah)
            tmp.set((float) (s.x[i] - ox), (float) (s.y[i] - oy), (float) (s.z[i] - oz));
            inverse.transformPosition(tmp);
            if (Math.abs(tmp.x) < 0.36f && tmp.y > 0.05f && tmp.y < 1.47f && tmp.z < 0.15f) {
                tmp.z = 0.15f;
                m.transformPosition(tmp);
                s.x[i] = ox + tmp.x;
                s.y[i] = oy + tmp.y;
                s.z[i] = oz + tmp.z;
            }
            if (s.y[i] < floor) {
                s.y[i] = floor;
            }
        };
        sim.step(ax, ay, az, gravity, damping, CARRY, wind.x, wind.y, wind.z,
                side.x * flutter, side.y * flutter, side.z * flutter,
                player.tickCount, ITERATIONS, player.getScale(), collider);
    }

    // ------------------------------------------------------------------ render

    /** Dipanggil dari RenderPlayerEvent.Post (titik asal = posisi render pemain). */
    public static void render(AbstractClientPlayer player, PlayerRenderer renderer, PoseStack poseStack,
                              MultiBufferSource buffers, float partialTick, int packedLight) {
        Cape cape = CAPES.get(player.getId());
        if (cape == null || !cape.sim.isReady() || !hasCape(player)) {
            return;
        }
        ClothSim sim = cape.sim;
        Vec3 offset = renderer.getRenderOffset(player, partialTick);
        double ox = Mth.lerp(partialTick, player.xo, player.getX()) + offset.x;
        double oy = Mth.lerp(partialTick, player.yo, player.getY()) + offset.y;
        double oz = Mth.lerp(partialTick, player.zo, player.getZ()) + offset.z;

        // Koreksi kalau badan sedang diputar sementara (misalnya pratinjau di inventory)
        Matrix4f renderM = ShazamPoses.bodyMatrix(player, partialTick, Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot));
        Matrix4f realM = ShazamPoses.bodyMatrix(player, partialTick, Mth.rotLerp(partialTick, cape.bodyYawO, cape.bodyYaw));
        Matrix4f correction = new Matrix4f(renderM).mul(realM.invert());

        float[] vx = new float[sim.count];
        float[] vy = new float[sim.count];
        float[] vz = new float[sim.count];
        Vector3f tmp = new Vector3f();
        for (int i = 0; i < sim.count; i++) {
            if (i < COLS) {
                tmp.set((float) REST_X[i], (float) REST_Y[i], (float) REST_Z[i]); // baris atas menempel persis di bahu
                renderM.transformPosition(tmp);
            } else {
                tmp.set((float) (Mth.lerp(partialTick, sim.rx[i], sim.x[i]) - ox),
                        (float) (Mth.lerp(partialTick, sim.ry[i], sim.y[i]) - oy),
                        (float) (Mth.lerp(partialTick, sim.rz[i], sim.z[i]) - oz));
                correction.transformPosition(tmp);
            }
            vx[i] = tmp.x;
            vy[i] = tmp.y;
            vz[i] = tmp.z;
        }

        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        PoseStack.Pose pose = poseStack.last();
        for (int r = 0; r < ROWS - 1; r++) {
            for (int c = 0; c < COLS - 1; c++) {
                int a = r * COLS + c;
                clothVertex(consumer, pose, vx, vy, vz, a, packedLight);
                clothVertex(consumer, pose, vx, vy, vz, a + COLS, packedLight);
                clothVertex(consumer, pose, vx, vy, vz, a + COLS + 1, packedLight);
                clothVertex(consumer, pose, vx, vy, vz, a + 1, packedLight);
            }
        }
        renderHood(player, renderM, consumer, pose, packedLight, partialTick);
    }

    private static void clothVertex(VertexConsumer vc, PoseStack.Pose pose, float[] vx, float[] vy, float[] vz, int i, int light) {
        int r = i / COLS;
        int c = i % COLS;
        int left = r * COLS + Math.max(0, c - 1);
        int right = r * COLS + Math.min(COLS - 1, c + 1);
        int up = Math.max(0, r - 1) * COLS + c;
        int down = Math.min(ROWS - 1, r + 1) * COLS + c;
        float tx = vx[right] - vx[left], ty = vy[right] - vy[left], tz = vz[right] - vz[left];
        float bx = vx[down] - vx[up], by = vy[down] - vy[up], bz = vz[down] - vz[up];
        vertex(vc, pose, vx[i], vy[i], vz[i], c / (float) (COLS - 1), r / (float) (ROWS - 1),
                ty * bz - tz * by, tz * bx - tx * bz, tx * by - ty * bx, light);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v,
                               float nx, float ny, float nz, int light) {
        float len = Mth.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1.0E-6f) {
            nx = 0f; ny = 1f; nz = 0f; len = 1f;
        }
        vc.addVertex(pose, x, y, z).setColor(255, 255, 255, 255).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(light).setNormal(pose, nx / len, ny / len, nz / len);
    }

    // ------------------------------------------------------------------ hood

    // Hood dipakai: sedikit lebih besar dari kepala, terbuka di depan wajah, ada ujung runcing di belakang atas
    private static final float HX = 0.29f;
    private static final float HY0 = -0.03f;
    private static final float HY1 = 0.53f;
    private static final float HZ0 = -0.19f;
    private static final float HZ1 = 0.29f;

    private static void renderHood(AbstractClientPlayer player, Matrix4f body, VertexConsumer vc, PoseStack.Pose pose,
                                   int light, float partialTick) {
        Matrix4f m = new Matrix4f(body);
        float[] head = ShazamPoses.headPose(player);
        if (ShazamClientState.isHoodUp(player.getId())) {
            if (head != null) {
                m.translate(head[0], head[1], head[2]).rotateY(head[4]).rotateX(head[3]);
            } else {
                float headYaw = Mth.wrapDegrees(Mth.rotLerp(partialTick, player.yHeadRotO, player.yHeadRot)
                        - Mth.rotLerp(partialTick, player.yBodyRotO, player.yBodyRot));
                float pitch = Mth.lerp(partialTick, player.xRotO, player.getXRot());
                m.translate(0f, NECK_Y, 0f).rotateY(-headYaw * Mth.DEG_TO_RAD).rotateX(-pitch * Mth.DEG_TO_RAD);
            }
            float top = HY1 + 0.03f;
            quad(vc, pose, m, light, -HX, HY1, HZ0, HX, HY1, HZ0, HX, top, HZ1, -HX, top, HZ1);           // atas
            quad(vc, pose, m, light, -HX, HY0, HZ1, HX, HY0, HZ1, HX, top, HZ1 + 0.02f, -HX, top, HZ1 + 0.02f); // belakang
            quad(vc, pose, m, light, HX, HY0, HZ0, HX, HY0, HZ1, HX, top, HZ1, HX, HY1, HZ0);              // sisi
            quad(vc, pose, m, light, -HX, HY0, HZ1, -HX, HY0, HZ0, -HX, HY1, HZ0, -HX, top, HZ1);          // sisi
            quad(vc, pose, m, light, -0.08f, top, HZ1, 0.08f, top, HZ1, 0f, top + 0.07f, HZ1 + 0.08f, 0f, top + 0.07f, HZ1 + 0.08f); // ujung
        } else {
            // Hood diturunkan: terlipat menggembung di belakang leher, ikut condong badan
            m.translate(0f, NECK_Y, 0f);
            if (head != null) {
                m.rotateX(head[5]);
            }
            int cols = 7;
            int rows = 4;
            float[][] px = new float[rows][cols];
            float[][] py = new float[rows][cols];
            float[][] pz = new float[rows][cols];
            for (int r = 0; r < rows; r++) {
                float t = r / (float) (rows - 1);
                for (int c = 0; c < cols; c++) {
                    float theta = -1.35f + 2.7f * c / (cols - 1);
                    float width = 0.24f + 0.05f * Mth.sin(Mth.PI * t);
                    float depth = 0.06f + 0.15f * Mth.sin(Mth.PI * 0.9f * t);
                    px[r][c] = Mth.sin(theta) * width;
                    py[r][c] = 0.02f - 0.30f * t;
                    pz[r][c] = 0.10f + Mth.cos(theta) * depth;
                }
            }
            for (int r = 0; r < rows - 1; r++) {
                for (int c = 0; c < cols - 1; c++) {
                    quad(vc, pose, m, light,
                            px[r][c], py[r][c], pz[r][c], px[r + 1][c], py[r + 1][c], pz[r + 1][c],
                            px[r + 1][c + 1], py[r + 1][c + 1], pz[r + 1][c + 1], px[r][c + 1], py[r][c + 1], pz[r][c + 1]);
                }
            }
        }
    }

    /** Satu sisi kain (empat titik di ruang lokal), diubah ke posisi render oleh matriks m. */
    private static void quad(VertexConsumer vc, PoseStack.Pose pose, Matrix4f m, int light,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4) {
        Vector3f a = m.transformPosition(new Vector3f(x1, y1, z1));
        Vector3f b = m.transformPosition(new Vector3f(x2, y2, z2));
        Vector3f c = m.transformPosition(new Vector3f(x3, y3, z3));
        Vector3f d = m.transformPosition(new Vector3f(x4, y4, z4));
        Vector3f n = new Vector3f(c).sub(a).cross(new Vector3f(d).sub(b));
        vertex(vc, pose, a.x, a.y, a.z, 0f, 0f, n.x, n.y, n.z, light);
        vertex(vc, pose, b.x, b.y, b.z, 0f, 0.25f, n.x, n.y, n.z, light);
        vertex(vc, pose, c.x, c.y, c.z, 1f, 0.25f, n.x, n.y, n.z, light);
        vertex(vc, pose, d.x, d.y, d.z, 1f, 0f, n.x, n.y, n.z, light);
    }
}
