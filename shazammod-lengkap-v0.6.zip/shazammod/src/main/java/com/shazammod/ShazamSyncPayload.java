package com.shazammod;

import java.util.List;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Server -> client: data buat HUD (energi, status, sisa cooldown tiap skill dalam tick). */
public record ShazamSyncPayload(boolean unlocked, boolean transformed, boolean storm, float energy,
                                List<Integer> cooldowns) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ShazamSyncPayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("sync"));

    public static final StreamCodec<ByteBuf, ShazamSyncPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.BOOL, ShazamSyncPayload::unlocked,
            ByteBufCodecs.BOOL, ShazamSyncPayload::transformed,
            ByteBufCodecs.BOOL, ShazamSyncPayload::storm,
            ByteBufCodecs.FLOAT, ShazamSyncPayload::energy,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list()), ShazamSyncPayload::cooldowns,
            ShazamSyncPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
