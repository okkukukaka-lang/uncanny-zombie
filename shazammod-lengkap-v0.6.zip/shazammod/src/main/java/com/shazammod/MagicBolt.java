package com.shazammod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** Petir sihir Shazam: cuma tampilan (petir emas tebal bercabang). Damage-nya dihitung terpisah. */
public class MagicBolt extends Entity {
    public static final int LIFETIME = 12;
    private static final EntityDataAccessor<Float> DATA_SIZE =
            SynchedEntityData.defineId(MagicBolt.class, EntityDataSerializers.FLOAT);
    private int age;

    public MagicBolt(EntityType<? extends MagicBolt> type, Level level) {
        super(type, level);
        this.noCulling = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_SIZE, 1.0f);
    }

    public void setBoltSize(float size) {
        this.entityData.set(DATA_SIZE, size);
    }

    public float boltSize() {
        return this.entityData.get(DATA_SIZE);
    }

    public int age() {
        return age;
    }

    @Override
    public void tick() {
        super.tick();
        age++;
        if (this.level().isClientSide) {
            if (age <= 3) {
                this.level().setSkyFlashTime(2); // langit berkilat
            }
        } else if (age > LIFETIME) {
            this.discard();
        }
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 256.0 * 256.0;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }
}
