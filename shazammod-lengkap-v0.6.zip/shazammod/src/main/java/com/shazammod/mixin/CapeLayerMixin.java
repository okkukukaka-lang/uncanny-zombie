package com.shazammod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.client.render.ShazamCape;

import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.layers.CapeLayer;

/** Sembunyikan jubah Minecraft biasa saat jubah 3D Shazam dipakai, biar nggak dobel. */
@Mixin(CapeLayer.class)
public abstract class CapeLayerMixin {
    @Inject(method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;FFFFFF)V",
            at = @At("HEAD"), cancellable = true)
    private void shazammod$hideVanillaCape(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                                           AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                                           float partialTick, float ageInTicks, float netHeadYaw, float headPitch,
                                           CallbackInfo ci) {
        if (ShazamCape.hasCape(player)) {
            ci.cancel();
        }
    }
}
