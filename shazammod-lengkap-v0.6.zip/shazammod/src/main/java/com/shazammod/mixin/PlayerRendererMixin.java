package com.shazammod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.mojang.blaze3d.vertex.PoseStack;
import com.shazammod.client.anim.ShazamPoses;
import com.shazammod.client.render.ShazamSuit;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;

@Mixin(PlayerRenderer.class)
public abstract class PlayerRendererMixin {
    /** Saat jadi Shazam, badan memakai tekstur kostum. */
    @Inject(method = "getTextureLocation(Lnet/minecraft/client/player/AbstractClientPlayer;)Lnet/minecraft/resources/ResourceLocation;",
            at = @At("HEAD"), cancellable = true)
    private void shazammod$suitTexture(AbstractClientPlayer player, CallbackInfoReturnable<ResourceLocation> cir) {
        ResourceLocation suit = ShazamSuit.suitFor(player);
        if (suit != null) {
            cir.setReturnValue(suit);
        }
    }

    /** Kemiringan seluruh badan (terbang rebah, membungkuk, berlutut). */
    @Inject(method = "setupRotations(Lnet/minecraft/client/player/AbstractClientPlayer;Lcom/mojang/blaze3d/vertex/PoseStack;FFFF)V",
            at = @At("TAIL"))
    private void shazammod$bodyTilt(AbstractClientPlayer player, PoseStack poseStack, float bob, float yBodyRot,
                                    float partialTick, float scale, CallbackInfo ci) {
        ShazamPoses.applyBodyTransform(player, poseStack, partialTick, scale);
    }

    /** Lengan orang pertama ikut memakai kostum (opsional: kalau gagal dipasang, game tetap jalan). */
    @ModifyVariable(method = "renderHand", at = @At("STORE"), require = 0)
    private ResourceLocation shazammod$suitHand(ResourceLocation original) {
        ResourceLocation suit = ShazamSuit.suitFor(Minecraft.getInstance().player);
        return suit != null ? suit : original;
    }
}
