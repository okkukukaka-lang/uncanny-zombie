package com.shazammod.mixin;

import java.util.Map;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.shazammod.client.render.ShazamSuit;

import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.resources.PlayerSkin;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/** Kostum Shazam selalu memakai model lengan lebar, walaupun skin aslinya model lengan ramping. */
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    @Shadow
    private Map<PlayerSkin.Model, EntityRenderer<? extends Player>> playerRenderers;

    @Inject(method = "getRenderer(Lnet/minecraft/world/entity/Entity;)Lnet/minecraft/client/renderer/entity/EntityRenderer;",
            at = @At("HEAD"), cancellable = true)
    private void shazammod$wideSuit(Entity entity, CallbackInfoReturnable<EntityRenderer<?>> cir) {
        if (entity instanceof AbstractClientPlayer player && ShazamSuit.forceWide(player)) {
            EntityRenderer<? extends Player> wide = playerRenderers.get(PlayerSkin.Model.WIDE);
            if (wide != null) {
                cir.setReturnValue(wide);
            }
        }
    }
}
