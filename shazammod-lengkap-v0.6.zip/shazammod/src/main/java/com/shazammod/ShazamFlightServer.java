package com.shazammod;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.Vec3;

/** Sisi server dari terbang Shazam: gelombang kejut, suara, dan animasi untuk pemain lain. */
public final class ShazamFlightServer {
    private ShazamFlightServer() {}

    private static final float MAX_SPEED = 5.5f;      // batas kecepatan yang dipercaya dari client
    private static final int IMPACT_COOLDOWN = 10;
    private static final Map<UUID, Long> LAST_IMPACT = new HashMap<>();

    public static void handle(ServerPlayer player, int action, float speed) {
        if (!ShazamPowers.isTransformed(player)) {
            return;
        }
        float s = Mth.clamp(speed, 0f, MAX_SPEED);
        ServerLevel level = player.serverLevel();
        switch (action) {
            case ShazamFlightPayload.LAUNCH -> {
                ShazamNetwork.playAnimToOthers(player, ShazamAnim.LAUNCH);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 1.5f, 0.6f);
            }
            case ShazamFlightPayload.LAND_SOFT -> ShazamNetwork.playAnimToOthers(player, ShazamAnim.LAND_SOFT);
            case ShazamFlightPayload.LAND_HERO -> impact(player, s, ShazamAnim.LAND_HERO);
            case ShazamFlightPayload.CRASH -> impact(player, s, ShazamAnim.CRASH);
            case ShazamFlightPayload.SONIC_BOOM -> sonicBoom(player);
            case ShazamFlightPayload.ROLL_LEFT -> ShazamNetwork.playAnimToOthers(player, ShazamAnim.ROLL_LEFT);
            case ShazamFlightPayload.ROLL_RIGHT -> ShazamNetwork.playAnimToOthers(player, ShazamAnim.ROLL_RIGHT);
            default -> { }
        }
    }

    /** Hero landing atau tabrakan: makin kencang, makin lebar dan sakit gelombang kejutnya. */
    private static void impact(ServerPlayer player, float speed, ShazamAnim anim) {
        long now = player.level().getGameTime();
        Long last = LAST_IMPACT.get(player.getUUID());
        if (last != null && now - last < IMPACT_COOLDOWN) {
            return;
        }
        LAST_IMPACT.put(player.getUUID(), now);
        ShazamNetwork.playAnimToOthers(player, anim);

        ServerLevel level = player.serverLevel();
        Vec3 center = player.position();
        double radius = 3.0 + speed * 1.2;
        float damage = 6f + speed * 6f;
        DamageSource source = ShazamPowers.forceSource(player);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius),
                m -> m.isAlive() && m instanceof Enemy && m.distanceToSqr(center) <= radius * radius)) {
            double distance = Math.sqrt(target.distanceToSqr(center));
            float falloff = (float) (1.0 - distance / radius * 0.6);
            target.hurt(source, damage * falloff);
            Vec3 away = new Vec3(target.getX() - center.x, 0, target.getZ() - center.z);
            Vec3 push = away.lengthSqr() < 1.0E-4 ? Vec3.ZERO : away.normalize().scale(0.8 + speed * 0.3);
            target.push(push.x, 0.4 + speed * 0.1, push.z);
        }
        level.playSound(null, center.x, center.y, center.z, SoundEvents.MACE_SMASH_GROUND_HEAVY, SoundSource.PLAYERS, 1.6f, 0.6f);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 1.0f, 0.6f);
    }

    private static void sonicBoom(ServerPlayer player) {
        ShazamNetwork.playAnimToOthers(player, ShazamAnim.SONIC_BOOM);
        ServerLevel level = player.serverLevel();
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 3.0f, 0.8f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 2.0f, 1.6f);
        Vec3 center = player.position();
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(6.0),
                m -> m.isAlive() && m instanceof Enemy)) {
            Vec3 away = new Vec3(target.getX() - center.x, 0, target.getZ() - center.z);
            if (away.lengthSqr() > 1.0E-4) {
                away = away.normalize();
                target.push(away.x * 1.2, 0.3, away.z * 1.2);
            }
        }
    }

    public static void forget(UUID id) {
        LAST_IMPACT.remove(id);
    }
}
