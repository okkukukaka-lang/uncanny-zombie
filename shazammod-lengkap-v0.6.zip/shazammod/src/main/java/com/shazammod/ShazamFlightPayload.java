package com.shazammod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: kejadian saat terbang (lepas landas, mendarat, tabrakan, sonic boom, barrel roll). */
public record ShazamFlightPayload(int action, float speed) implements CustomPacketPayload {
    public static final int LAUNCH = 0;
    public static final int LAND_SOFT = 1;
    public static final int LAND_HERO = 2;
    public static final int CRASH = 3;
    public static final int SONIC_BOOM = 4;
    public static final int ROLL_LEFT = 5;
    public static final int ROLL_RIGHT = 6;

    public static final CustomPacketPayload.Type<ShazamFlightPayload> TYPE =
            new CustomPacketPayload.Type<>(ShazamMod.id("flight"));

    public static final StreamCodec<ByteBuf, ShazamFlightPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ShazamFlightPayload::action,
            ByteBufCodecs.FLOAT, ShazamFlightPayload::speed,
            ShazamFlightPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
